PI = 3.14
radius = float(input('Please Enter the Radius of a Sphere: '))
Volume = (4 / 3) * PI * radius * radius * radius
print("\n The Volume of a Sphere = %.2f" %Volume)
print("\n The Volume of a Sphere = %.2f" %Volume)
print("\n The Volume of a Sphere = %.2f" %Volume)